from alembic import context
from mogu.config import Settings
from mogu.db import Base, database
engine,_=database(Settings.env().database_url)
try:
    with engine.connect() as connection:
        context.configure(connection=connection,target_metadata=Base.metadata)
        with context.begin_transaction():
            context.run_migrations()
finally:
    engine.dispose()
