"""Invalidate live sessions across revoke/regrant and stop/resume."""
from alembic import op
import sqlalchemy as sa

revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('login_grants', sa.Column('member_version', sa.Integer(), nullable=False, server_default='1'))
    op.add_column('login_grants', sa.Column('tenant_version', sa.Integer(), nullable=False, server_default='1'))
    op.add_column('memberships', sa.Column('access_version', sa.Integer(), nullable=False, server_default='1'))
    op.add_column('tenants', sa.Column('access_version', sa.Integer(), nullable=False, server_default='1'))


def downgrade():
    op.drop_column('login_grants', 'tenant_version')
    op.drop_column('login_grants', 'member_version')
    op.drop_column('tenants', 'access_version')
    op.drop_column('memberships', 'access_version')
