#!/bin/sh
set -eu
umask 077
# Output is a DB dump; send directly to encrypted backup storage.
# Do not copy live Chromium profiles. This backup intentionally excludes them.
docker compose exec -T db pg_dump -U mogu -d mogu -Fc
