import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import inspect, text
from mogu.db import database


def test_existing_0001_data_survives_0002(monkeypatch, tmp_path):
    url = 'sqlite:///' + str(tmp_path / 'migration.db')
    monkeypatch.setenv('DATABASE_URL', url)
    command.upgrade(Config('alembic.ini'), '0001')
    engine, _ = database(url)
    with engine.begin() as c:
        c.execute(text("INSERT INTO tenants (id,name,stopped,daily_limit_minor) VALUES ('tenant','existing',0,0)"))
        c.execute(text("INSERT INTO memberships (id,tenant_id,telegram_id,role,active) VALUES ('member','tenant',123,'owner',1)"))
    command.upgrade(Config('alembic.ini'), 'head')
    with engine.connect() as c:
        assert c.scalar(text('SELECT access_version FROM memberships')) == 1
        assert c.scalar(text('SELECT access_version FROM tenants')) == 1
        assert c.scalar(text('SELECT telegram_id FROM memberships')) == 123
    command.downgrade(Config('alembic.ini'), '0001')
    assert 'access_version' not in {x['name'] for x in inspect(engine).get_columns('memberships')}
    command.upgrade(Config('alembic.ini'), 'head')
    engine.dispose()
