"""Run with TEST_POSTGRES_URL pointing to a disposable PostgreSQL database."""
import os
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url

from mogu.db import Job, Member, Tenant, database
from mogu.locks import Busy, profile_lock
from mogu.service import Service
from mogu.worker import Worker

pytestmark = pytest.mark.postgres


@pytest.fixture
def pg_setup(monkeypatch):
    url = os.getenv('TEST_POSTGRES_URL')
    if not url:
        pytest.skip('TEST_POSTGRES_URL not configured')
    schema = 'test_mogu_' + uuid.uuid4().hex
    admin_engine = create_engine(url)
    with admin_engine.begin() as c:
        c.execute(text('CREATE SCHEMA ' + schema))
    scoped_url = make_url(url).update_query_dict({'options': '-csearch_path=' + schema}).render_as_string(hide_password=False)
    engine = None
    try:
        monkeypatch.setenv('DATABASE_URL', scoped_url)
        command.upgrade(Config('alembic.ini'), 'head')
        engine, sessions = database(scoped_url)
        with sessions.begin() as s:
            t = Tenant(name='test'); s.add(t); s.flush()
            s.add(Member(tenant_id=t.id, telegram_id=1, role='owner'))
        service = Service(sessions)
        iid = service.add_identity(1, 'account', 'test')
        cid = service.add_cabinet(1, iid, 'client', 'test')
        yield service, engine, sessions, iid, cid
    finally:
        if engine is not None:
            engine.dispose()
        with admin_engine.begin() as c:
            c.execute(text('DROP SCHEMA ' + schema + ' CASCADE'))
        admin_engine.dispose()


def test_postgres_parallel_duplicate_and_claim(pg_setup):
    service, _, sessions, _, cid = pg_setup
    with ThreadPoolExecutor(4) as pool:
        ids = list(pool.map(lambda _: service.submit(1, cid, 'status', 'same'), range(4)))
    assert len(set(ids)) == 1
    with ThreadPoolExecutor(4) as pool:
        claims = list(pool.map(lambda _: Worker(service, None).claim(), range(4)))
    assert claims.count(ids[0]) == 1


async def test_postgres_advisory_lock_survives_commit(pg_setup, tmp_path):
    _, engine, _, iid, _ = pg_setup
    async with profile_lock(engine, tmp_path / 'first-host-lock', iid) as lease:
        lease.check()
        # Different file locks: contention here must come from PostgreSQL.
        with pytest.raises(Busy):
            async with profile_lock(engine, tmp_path / 'second-host-lock', iid):
                pass
    async with profile_lock(engine, tmp_path / 'second-host-lock', iid) as lease:
        lease.check()


def test_access_epoch_migration_preserves_existing_members(pg_setup):
    _, _, sessions, _, _ = pg_setup
    command.downgrade(Config('alembic.ini'), '0001')
    command.upgrade(Config('alembic.ini'), 'head')
    with sessions() as s:
        assert s.query(Member).one().access_version == 1
        assert s.query(Tenant).one().access_version == 1
