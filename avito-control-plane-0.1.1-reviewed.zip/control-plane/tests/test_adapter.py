from pathlib import Path
import shutil
import os
import pytest
from mogu.adapter import AvitoAdapter,ScenarioError


def test_unverified_manifest_disabled():
    with pytest.raises(ScenarioError):AvitoAdapter(None,{'verified_live':False},True)
    with pytest.raises(ScenarioError):AvitoAdapter(None,{'verified_live':True,'tested_at':'fixture'},False)


@pytest.mark.browser
async def test_exact_client_switch_in_real_fixture_browser():
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        try:
            browser=await p.chromium.launch(headless=True,chromium_sandbox=True,executable_path=None if Path(p.chromium.executable_path).exists() else shutil.which("chromium"))
        except Exception as e:
            if os.getenv('REQUIRE_BROWSER_TESTS') == '1':
                raise
            pytest.skip('Host Chromium/sandbox unavailable: '+type(e).__name__)
        try:
            page=await browser.new_page()
            html=Path('tests/fixtures/agency.html').read_text()
            await page.route('https://www.avito.ru/**',lambda route:route.fulfill(body=html,content_type='text/html'))
            m={'verified_live':True,'tested_at':'fixture-only','identity':'#account','identity_attribute':'data-id',
               'login_required':'.login','challenge':'.challenge','agency_url':'https://www.avito.ru/profile/agency/clients',
               'client_row':'.client','client_id_attribute':'data-id','clients_empty':'.empty',
               'switch_button':'В профиль','context':'#context','context_attribute':'data-id'}
            a=AvitoAdapter(page,m,True)
            await a.switch('account-1','12')
            assert await page.locator('#context').get_attribute('data-id')=='12'
            with pytest.raises(ScenarioError):await a.context('account-1','123')
            with pytest.raises(ScenarioError):await a.switch('account-1','1')
            with pytest.raises(ScenarioError):await a.context('wrong','12')
        finally:await browser.close()
