import pytest
from mogu.db import Base,Member,Tenant,database
from mogu.service import Service


@pytest.fixture
def setup(tmp_path):
    engine,sessions=database('sqlite:///'+str(tmp_path/'test.db'))
    Base.metadata.create_all(engine)
    with sessions.begin() as s:
        t=Tenant(name='agency');s.add(t);s.flush();tid=t.id
        s.add(Member(tenant_id=tid,telegram_id=1,role='owner'))
    service=Service(sessions)
    iid=service.add_identity(1,'account-1','Agency')
    cid=service.add_cabinet(1,iid,'client-1','Client')
    return service,engine,sessions,tid,iid,cid
