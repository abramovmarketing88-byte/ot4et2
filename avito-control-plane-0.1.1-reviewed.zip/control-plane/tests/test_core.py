import hashlib,hmac,json,time
from urllib.parse import urlencode
import pytest
from sqlalchemy import select
from mogu.db import Cabinet,Job,LoginGrant,Member,Tenant
from mogu.security import Denied,cabinet_access,membership,validate_init_data
from mogu.intent import parse
from mogu.locks import Busy,profile_lock
from mogu.worker import Worker
from contextlib import asynccontextmanager


def signed(uid=1,stamp=None,token='test-token'):
    data={'auth_date':str(int(time.time()) if stamp is None else stamp),'user':json.dumps({'id':uid})}
    key=hmac.new(b'WebAppData',token.encode(),hashlib.sha256).digest()
    data['hash']=hmac.new(key,'\n'.join(f'{k}={v}' for k,v in sorted(data.items())).encode(),hashlib.sha256).hexdigest()
    return urlencode(data)


def test_registration_deny_default(setup):
    service,_,sessions,*_=setup
    with sessions() as s:
        with pytest.raises(Denied):membership(s,999)
    service.add_member(1,2,'operator')
    with sessions() as s:assert membership(s,2).role=='operator'


@pytest.mark.parametrize('role', ['operator','observer'])
def test_foreign_cabinet(setup,role):
    service,_,_,_,_,cid=setup
    service.add_member(1,2,role)
    assert service.cabinets(2)==[]
    with pytest.raises(Denied):service.submit(2,cid,'status','x')


def test_observer_read_only(setup):
    service,_,_,_,_,cid=setup
    service.add_member(1,2,'observer');service.grant(1,2,cid,True)
    service.submit(2,cid,'ads','read')
    with pytest.raises(Denied):service.submit(2,cid,'mogu_preview','write')


def test_tenant_boundary(setup):
    service,_,sessions,_,iid,_=setup
    with sessions.begin() as s:
        t=Tenant(name='foreign');s.add(t);s.flush()
        c=Cabinet(tenant_id=t.id,identity_id=iid,external_id='foreign',name='foreign');s.add(c);s.flush();cid=c.id
    with sessions() as s:
        with pytest.raises(Denied):cabinet_access(s,1,cid)


def test_duplicate_callback_and_conflicting_key(setup):
    service,_,sessions,_,_,cid=setup
    a=service.submit(1,cid,'status','same')
    assert a==service.submit(1,cid,'status','same')
    with pytest.raises(Denied):service.submit(1,cid,'ads','same')
    with sessions() as s:assert len(list(s.scalars(select(Job))))==1


def test_operator_cannot_administer(setup):
    service,*_=setup
    service.add_member(1,2,'operator')
    with pytest.raises(Denied):service.add_member(2,3,'admin')
    with pytest.raises(Denied):service.revoke(2,1)
    with pytest.raises(Denied):service.stop(2)


@pytest.mark.parametrize('action',['mogu_apply','delete','shell','change_price'])
def test_mutations_unavailable(setup,action):
    service,_,_,_,_,cid=setup
    with pytest.raises(Denied):service.submit(1,cid,action,'financial')


def test_global_stop(setup):
    service,_,_,_,iid,cid=setup
    service.stop(1)
    with pytest.raises(Denied):service.submit(1,cid,'status','x')
    with pytest.raises(Denied):service.login_grant(1,iid)
    service.stop(1,False)
    service.submit(1,cid,'status','y')


def test_grant_single_use_bound_to_user(setup):
    service,_,_,_,iid,_=setup
    service.add_member(1,2,'admin')
    token=service.login_grant(1,iid)
    with pytest.raises(Denied):service.consume_grant(2,token)
    assert service.consume_grant(1,token)==iid
    with pytest.raises(Denied):service.consume_grant(1,token)


def test_grant_expiry(setup):
    service,_,sessions,_,iid,_=setup
    token=service.login_grant(1,iid)
    with sessions.begin() as s:
        s.get(LoginGrant,hashlib.sha256(token.encode()).hexdigest()).expires_at=0
    with pytest.raises(Denied):service.consume_grant(1,token)


def test_revocation_invalidates_grant(setup):
    service,_,_,_,iid,_=setup
    service.add_member(1,2,'admin');token=service.login_grant(2,iid);service.revoke(1,2)
    with pytest.raises(Denied):service.consume_grant(2,token)


def test_telegram_auth():
    assert validate_init_data(signed(), 'test-token')==1
    for raw in [signed(stamp=0),signed(stamp=int(time.time())+300),signed()+'&user=x',signed(uid=2)[:-1]+'x']:
        with pytest.raises((Denied,ValueError)):validate_init_data(raw,'test-token')
    with pytest.raises(Denied):validate_init_data(signed(),'wrong')


@pytest.mark.parametrize('utterance',['удали всё','включи могу сегодня','выполни javascript','Открой клиента Иванов'])
def test_unknown_text_never_executes(utterance):
    assert parse(utterance) is None


async def test_exclusive_profile_lock(setup,tmp_path):
    _,engine,*_=setup
    async with profile_lock(engine,tmp_path,'profile'):
        with pytest.raises(Busy):
            async with profile_lock(engine,tmp_path,'profile'):pass
    async with profile_lock(engine,tmp_path,'profile'):pass


class FakeBrowsers:
    def __init__(self,error=None):self.error=error;self.calls=0
    @asynccontextmanager
    async def open(self,iid):
        if self.error:raise self.error
        yield object()
    def adapter(self,page):return self
    async def execute(self,action,account,client):
        self.calls+=1
        return {'client_id':client,'context_verified':True}


async def test_worker_executes_read(setup):
    service,_,sessions,_,_,cid=setup
    jid=service.submit(1,cid,'status','read');b=FakeBrowsers();await Worker(service,b).tick()
    with sessions() as s:
        j=s.get(Job,jid);assert j.state=='SUCCEEDED';assert j.result['client_id']=='client-1'
    assert b.calls==1


async def test_revoke_while_queued(setup):
    service,_,sessions,_,_,cid=setup
    service.add_member(1,2,'operator');service.grant(1,2,cid)
    jid=service.submit(2,cid,'status','read');service.revoke(1,2)
    b=FakeBrowsers();await Worker(service,b).tick()
    with sessions() as s:assert s.get(Job,jid).state=='CANCELLED'
    assert b.calls==0


@pytest.mark.parametrize('error,state',[(RuntimeError('crash'),'FAILED')])
async def test_browser_crash(setup,error,state):
    service,_,sessions,_,_,cid=setup
    jid=service.submit(1,cid,'status','crash');await Worker(service,FakeBrowsers(error)).tick()
    with sessions() as s:assert s.get(Job,jid).state==state


async def test_auth_expired_and_challenge(setup):
    from mogu.adapter import AuthRequired,HumanRequired
    service,_,sessions,_,_,cid=setup
    for error,state in [(AuthRequired(),'WAITING_AUTH'),(HumanRequired(),'WAITING_HUMAN')]:
        jid=service.submit(1,cid,'status',state);await Worker(service,FakeBrowsers(error)).tick()
        with sessions() as s:assert s.get(Job,jid).state==state


def test_recovery_never_repeats_unknown_mutation(setup):
    service,_,sessions,tid,_,cid=setup
    a=service.submit(1,cid,'status','a')
    with sessions.begin() as s:
        s.get(Job,a).state='RUNNING'
        j=Job(tenant_id=tid,actor_id=1,cabinet_id=cid,action='mogu_apply',request_key='b',state='VERIFYING');s.add(j);s.flush();b=j.id
    Worker(service,None).recover()
    with sessions() as s:
        assert s.get(Job,a).state=='QUEUED';assert s.get(Job,b).state=='UNKNOWN'
    Worker(service,None).recover()
    with sessions() as s:assert s.get(Job,b).state=='UNKNOWN'


async def test_stop_queued(setup):
    service,_,sessions,_,_,cid=setup
    jid=service.submit(1,cid,'status','stop');service.cancel(1,jid)
    b=FakeBrowsers();assert await Worker(service,b).tick() is False
    with sessions() as s:assert s.get(Job,jid).state=='CANCELLED'
    assert b.calls==0


async def test_concurrent_claim_only_one(setup):
    from concurrent.futures import ThreadPoolExecutor
    service,_,sessions,_,_,cid=setup
    jid=service.submit(1,cid,'status','claim')
    with ThreadPoolExecutor(2) as pool:out=list(pool.map(lambda _:Worker(service,None).claim(),range(2)))
    assert out.count(jid)==1


async def test_ten_users_shared_identity_are_serialized(setup):
    import asyncio
    service,_,sessions,_,_,cid=setup
    class SerialBrowsers(FakeBrowsers):
        def __init__(self):super().__init__();self.gate=asyncio.Lock();self.active=0;self.peak=0
        @asynccontextmanager
        async def open(self,iid):
            async with self.gate:
                self.active+=1;self.peak=max(self.peak,self.active)
                try:yield object()
                finally:self.active-=1
        async def execute(self,action,account,client):
            await asyncio.sleep(.01)
            return await super().execute(action,account,client)
    ids=[]
    for uid in range(2,12):
        service.add_member(1,uid,'operator');service.grant(1,uid,cid)
        ids.append(service.submit(uid,cid,'status','user:'+str(uid)))
    b=SerialBrowsers()
    await asyncio.gather(*(Worker(service,b).tick() for _ in ids))
    with sessions() as s:assert all(s.get(Job,jid).state=='SUCCEEDED' for jid in ids)
    assert b.peak==1 and b.calls==10


async def test_stop_running_read_cancels_browser_operation(setup):
    import asyncio
    service,_,sessions,_,_,cid=setup
    started=asyncio.Event()
    class Slow(FakeBrowsers):
        async def execute(self,*args):
            started.set();await asyncio.Event().wait()
    jid=service.submit(1,cid,'status','running')
    task=asyncio.create_task(Worker(service,Slow()).tick())
    await asyncio.wait_for(started.wait(),1)
    service.cancel(1,jid)
    await asyncio.wait_for(task,2)
    with sessions() as s:assert s.get(Job,jid).state=='CANCELLED'
