from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from mogu.api import create_app
from mogu.config import Settings
from test_core import signed


def client(setup,tmp_path):
    service,engine,*_=setup
    settings=Settings('', 'test-token','https://testserver',tmp_path,Path('scenarios/avito.json'))
    return TestClient(create_app(settings,service,run_worker=False))


def test_health_and_portal(setup,tmp_path):
    with client(setup,tmp_path) as c:
        assert c.get('/health/ready').status_code==200
        r=c.get('/');assert r.status_code==200
        assert r.headers['cache-control']=='no-store'
        assert c.get('/portal.js').status_code==200


def test_auth_origin_and_grant(setup,tmp_path):
    *_,iid,cid=setup
    with client(setup,tmp_path) as c:
        assert c.get('/api/identities').status_code==403
        headers={'X-Telegram-Init-Data':signed(),'Origin':'https://testserver'}
        r=c.get('/api/identities',headers=headers);assert r.status_code==200;assert r.json()[0]['id']==iid
        assert c.post('/api/login/grant',headers=headers,json={'identity_id':iid}).status_code==200
        headers['Origin']='https://evil.example'
        assert c.post('/api/login/grant',headers=headers,json={'identity_id':iid}).status_code==403


def test_websocket_denies_forged_origin(setup,tmp_path):
    from starlette.websockets import WebSocketDisconnect
    with client(setup,tmp_path) as c:
        with pytest.raises(WebSocketDisconnect):
            with c.websocket_connect('/remote',headers={'Origin':'https://evil.example'}):pass


def test_remote_session_verifies_same_server_browser(setup,tmp_path):
    import asyncio
    from contextlib import asynccontextmanager
    from mogu.db import Identity
    class Page:
        async def goto(self,*args,**kw):pass
        async def screenshot(self,**kw):return b'fixture-not-a-real-screen'
    class Manager:
        gate=asyncio.Lock()
        @asynccontextmanager
        async def open(self,iid,**kw):yield Page()
        def adapter(self,page):return self
        async def auth(self,account):assert account=='account-1'
    service,_,sessions,_,iid,_=setup
    settings=Settings('', 'test-token','https://testserver',tmp_path,Path('scenarios/avito.json'))
    with TestClient(create_app(settings,service,Manager(),run_worker=False)) as c:
        headers={'X-Telegram-Init-Data':signed(),'Origin':'https://testserver'}
        grant=c.post('/api/login/grant',headers=headers,json={'identity_id':iid}).json()['grant']
        with c.websocket_connect('/remote',headers={'Origin':'https://testserver'}) as ws:
            ws.send_json({'init_data':signed(),'grant':grant})
            assert 'status' in ws.receive_json()
            assert 'frame' in ws.receive_json()
            ws.send_json({'type':'verify'})
            assert ws.receive_json()['status']=='Авторизация подтверждена'
        with sessions() as s:assert s.get(Identity,iid).auth_state=='VERIFIED'
