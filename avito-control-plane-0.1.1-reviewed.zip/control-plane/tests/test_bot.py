from datetime import datetime,timezone
from pathlib import Path
from aiogram import Bot
from aiogram.client.session.base import BaseSession
from aiogram.types import Message,User,Chat,Update,CallbackQuery
from mogu.bot import create_dispatcher
from mogu.config import Settings


class TelegramStub(BaseSession):
    def __init__(self):super().__init__();self.sent=[]
    async def close(self):pass
    async def stream_content(self,*args,**kwargs):
        if False:yield b''
    async def make_request(self,bot,method,timeout=None):
        self.sent.append(method)
        if method.__api_method__=='sendMessage':
            return Message(message_id=100,chat=Chat(id=method.chat_id,type='private'),date=datetime.now(timezone.utc),text=method.text)
        return True


async def test_real_aiogram_dispatcher_deny_and_allow(setup,tmp_path):
    service,*_=setup
    session=TelegramStub();bot=Bot('123456:'+('A'*35),session=session)
    settings=Settings('', '', 'https://example.ru',tmp_path,Path('scenarios/avito.json'))
    dp,_=create_dispatcher(service,settings,bot)
    for uid in [999,1]:
        update=Update(update_id=uid,message=Message(message_id=uid,chat=Chat(id=uid,type='private'),from_user=User(id=uid,is_bot=False,first_name='Test'),date=datetime.now(timezone.utc),text='/start'))
        await dp.feed_update(bot,update)
    assert 'Нет доступа' in session.sent[0].text
    assert session.sent[1].reply_markup.inline_keyboard
    assert 'Выберите кабинет' in session.sent[1].text


async def test_real_aiogram_callback_is_idempotent(setup,tmp_path):
    from sqlalchemy import select
    from mogu.db import Job
    service,_,sessions,_,_,cid=setup
    session=TelegramStub();bot=Bot('123456:'+('A'*35),session=session)
    dp,_=create_dispatcher(service,Settings('','','https://example.ru',tmp_path,Path('scenarios/avito.json')),bot)
    for i in [1,2]:
        callback=CallbackQuery(id=str(i),from_user=User(id=1,is_bot=False,first_name='Owner'),chat_instance='test',data='do:status:'+cid,
            message=Message(message_id=45,chat=Chat(id=1,type='private'),date=datetime.now(timezone.utc)))
        await dp.feed_update(bot,Update(update_id=i,callback_query=callback))
    with sessions() as s:assert len(list(s.scalars(select(Job))))==1
