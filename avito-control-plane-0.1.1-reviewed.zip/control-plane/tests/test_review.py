"""Regression tests for independently found review defects."""
import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlencode

import pytest
from sqlalchemy import select
from fastapi.testclient import TestClient

from mogu.api import create_app
from mogu.adapter import AvitoAdapter, ScenarioError
from mogu.config import Settings
from mogu.db import Job, Member, Permission, Tenant
from mogu.locks import ProfileLease
from mogu.security import Denied, validate_init_data
from mogu.worker import Worker
from test_core import FakeBrowsers, signed


def test_admin_cannot_demote_another_admin(setup):
    service, *_ = setup
    service.add_member(1, 2, 'admin')
    service.add_member(1, 3, 'admin')
    with pytest.raises(Denied):
        service.add_member(2, 3, 'operator')
    service.add_member(1, 3, 'operator')


def test_reactivation_does_not_restore_old_cabinet_permissions(setup):
    service, _, _, _, _, cid = setup
    service.add_member(1, 2, 'operator')
    service.grant(1, 2, cid)
    service.revoke(1, 2)
    service.add_member(1, 2, 'operator')
    assert service.cabinets(2) == []


def test_idempotent_member_assignment_preserves_permissions(setup):
    service, _, _, _, _, cid = setup
    service.add_member(1, 2, 'operator')
    service.grant(1, 2, cid)
    service.add_member(1, 2, 'operator')
    assert len(service.cabinets(2)) == 1


def test_stop_resume_cannot_revive_old_jobs_or_login_grants(setup):
    service, _, sessions, _, iid, cid = setup
    jid = service.submit(1, cid, 'status', 'before-kill')
    token = service.login_grant(1, iid)
    stamp = service.login_stamp(1, iid)
    service.stop(1)
    service.stop(1, False)
    with pytest.raises(Denied):
        service.consume_grant(1, token)
    with pytest.raises(Denied):
        service.login_stamp(1, iid, stamp)
    with sessions() as s:
        assert s.get(Job, jid).state == 'CANCELLED'


def test_consumed_session_revoked_even_after_regrant(setup):
    service, _, _, _, iid, _ = setup
    service.add_member(1, 2, 'admin')
    token = service.login_grant(2, iid)
    _, stamp = service.consume_grant(2, token, with_stamp=True)
    service.revoke(1, 2)
    service.add_member(1, 2, 'admin')
    with pytest.raises(Denied):
        service.login_stamp(2, iid, stamp)


def test_role_demotion_revokes_identity_login_and_grant(setup):
    service, *_ = setup
    service.add_member(1, 2, 'admin')
    iid = service.add_identity(2, 'another-account', 'Other')
    token = service.login_grant(2, iid)
    service.add_member(1, 2, 'operator')
    with pytest.raises(Denied):
        service.login_grant(2, iid)
    with pytest.raises(Denied):
        service.consume_grant(2, token)


@pytest.mark.parametrize('raw', [None, {}, 'hash='+'я'*64, 'broken', urlencode({'hash':'a'*64, 'user':'x'*20000})])
def test_malformed_telegram_data_is_denied_without_server_error(raw):
    with pytest.raises(Denied):
        validate_init_data(raw, 'test-token')


def test_profile_lease_detects_reconnection():
    class Connection:
        def scalar(self, query): return 101
        def commit(self): pass
    with pytest.raises(RuntimeError, match='lock_session_changed'):
        ProfileLease(Connection(), 42, 100).check()


def test_manifest_verification_flag_must_be_boolean():
    with pytest.raises(ScenarioError):
        AvitoAdapter(None, {'verified_live':'false', 'tested_at':'fixture'}, True)


async def test_redirect_to_untrusted_origin_is_rejected():
    class Page:
        url = 'https://www.avito.ru/'
        async def goto(self, *args, **kwargs): self.url = 'https://evil.example/'
    a = AvitoAdapter(Page(), {'verified_live':True, 'tested_at':'fixture'}, True)
    with pytest.raises(ScenarioError, match='route_not_allowed'):
        await a.go('https://www.avito.ru/')


async def test_unknown_action_in_queue_never_opens_browser(setup):
    service, _, sessions, tid, _, cid = setup
    with sessions.begin() as s:
        j = Job(tenant_id=tid, actor_id=1, cabinet_id=cid, action='mogu_apply', request_key='injected')
        s.add(j); s.flush(); jid = j.id
    browsers = FakeBrowsers()
    await Worker(service, browsers).tick()
    assert browsers.calls == 0
    with sessions() as s: assert s.get(Job, jid).state == 'CANCELLED'


async def test_hung_read_times_out_and_releases_browser(setup):
    service, _, sessions, _, _, cid = setup
    class Hung(FakeBrowsers):
        settings = SimpleNamespace(job_timeout_seconds=.05)
        closed = False
        @asynccontextmanager
        async def open(self, iid):
            try: yield object()
            finally: self.closed = True
        async def execute(self, *args): await asyncio.Event().wait()
    browser = Hung()
    jid = service.submit(1, cid, 'status', 'hung')
    await asyncio.wait_for(Worker(service, browser).tick(), 1)
    assert browser.closed
    with sessions() as s:
        assert s.get(Job, jid).result['reason'] == 'job_timeout'


def test_waiting_login_does_not_suppress_final_notification(setup):
    service, _, sessions, _, iid, cid = setup
    jid = service.submit(1, cid, 'status', 'notification')
    w = Worker(service, None)
    w.finish(jid, 'WAITING_AUTH', {'reason':'login_required'})
    with sessions.begin() as s: s.get(Job, jid).notified = True
    service.complete_login(1, iid, service.login_stamp(1, iid), True)
    with sessions() as s:
        assert s.get(Job, jid).state == 'QUEUED'
        assert not s.get(Job, jid).notified
    w.finish(jid, 'SUCCEEDED', {'ok':True})
    with sessions() as s: assert not s.get(Job, jid).notified


async def test_stale_notification_ack_cannot_hide_new_result(setup, tmp_path):
    from mogu.bot import create_dispatcher
    service, _, sessions, _, _, cid = setup
    jid = service.submit(1, cid, 'status', 'notification-race')
    w = Worker(service, None)
    w.finish(jid, 'WAITING_AUTH', {})
    sent = asyncio.Event()
    class Bot:
        async def send_message(self, *args, **kwargs):
            w.finish(jid, 'SUCCEEDED', {'ok':True})
            sent.set()
    settings = Settings('', '', 'https://example.ru', tmp_path, Path('scenarios/avito.json'))
    _, notify = create_dispatcher(service, settings, Bot())
    task = asyncio.create_task(notify())
    try:
        await asyncio.wait_for(sent.wait(), 2)
        await asyncio.sleep(0)
        with sessions() as s: assert not s.get(Job, jid).notified
    finally:
        task.cancel(); await asyncio.gather(task, return_exceptions=True)


def test_revocation_between_frame_and_input_blocks_keyboard(setup, tmp_path):
    service, _, _, _, iid, _ = setup
    service.add_member(1, 2, 'admin')
    entered = []
    class Page:
        async def goto(self, *args, **kwargs): pass
        async def screenshot(self, **kwargs): return b'fixture'
        class keyboard:
            @staticmethod
            async def insert_text(value): entered.append(value)
    class Browsers:
        @asynccontextmanager
        async def open(self, iid, **kwargs): yield Page()
    settings = Settings('', 'test-token', 'https://testserver', tmp_path, Path('scenarios/avito.json'))
    with TestClient(create_app(settings, service, Browsers(), run_worker=False)) as c:
        token = service.login_grant(2, iid)
        with c.websocket_connect('/remote', headers={'Origin':'https://testserver'}) as ws:
            ws.send_json({'init_data':signed(2), 'grant':token})
            assert 'status' in ws.receive_json()
            assert 'frame' in ws.receive_json()
            service.revoke(1, 2)
            ws.send_json({'type':'text','text':'not-a-password-test'})
            assert 'error' in ws.receive_json()
    assert entered == []


@pytest.mark.parametrize('url', ['http://example.ru', 'https://user:pass@example.ru', 'https://example.ru/path', 'https://example.ru/?q=x'])
def test_public_url_must_be_secure_origin(url, tmp_path):
    with pytest.raises(ValueError):
        Settings('', '', url, tmp_path, Path('scenarios/avito.json'))


def test_parallel_duplicate_submissions_return_one_job(setup):
    from concurrent.futures import ThreadPoolExecutor
    service, _, sessions, _, _, cid = setup
    with ThreadPoolExecutor(4) as pool:
        ids = list(pool.map(lambda _: service.submit(1, cid, 'status', 'parallel-duplicate'), range(4)))
    assert len(set(ids)) == 1


def test_stale_grant_versions_denied_after_reactivation(setup):
    import hashlib
    from mogu.db import LoginGrant
    service, _, sessions, _, iid, _ = setup
    service.add_member(1, 2, 'admin')
    token = service.login_grant(2, iid)
    service.revoke(1, 2)
    service.add_member(1, 2, 'admin')
    # Models an issuance transaction that committed after the revoke invalidated known tokens.
    with sessions.begin() as s:
        s.get(LoginGrant, hashlib.sha256(token.encode()).hexdigest()).used = False
    with pytest.raises(Denied, match='grant_revoked'):
        service.consume_grant(2, token)
