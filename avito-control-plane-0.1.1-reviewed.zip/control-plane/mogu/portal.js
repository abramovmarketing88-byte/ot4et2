'use strict';
const $ = id => document.getElementById(id);
const init = window.Telegram?.WebApp?.initData || '';
const headers = {'X-Telegram-Init-Data': init, 'Content-Type':'application/json'};
let ws;
function send(data) { if (ws?.readyState === 1) ws.send(JSON.stringify(data)); }
async function load() {
  const r = await fetch('/api/identities', {headers});
  if (!r.ok) { $('status').textContent = 'Нет доступа. Откройте окно заново из Telegram.'; return; }
  for (const item of await r.json()) { const o=document.createElement('option');o.value=item.id;o.textContent=item.name+' · '+item.state;$('profiles').append(o); }
}
$('open').onclick=async()=>{
  if(ws && ws.readyState < 2) return;
  const r=await fetch('/api/login/grant',{method:'POST',headers,body:JSON.stringify({identity_id:$('profiles').value})});
  if(!r.ok){$('status').textContent='Нет доступа';return;}
  const data=await r.json();
  ws=new WebSocket('wss://'+location.host+'/remote');
  ws.onopen=()=>send({init_data:init,grant:data.grant});
  ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.frame)$('screen').src='data:image/jpeg;base64,'+m.frame;if(m.status||m.error)$('status').textContent=m.status||m.error;};
  ws.onclose=()=>{$('screen').removeAttribute('src');};
};
$('screen').onclick=e=>{const r=e.target.getBoundingClientRect();send({type:'click',x:(e.clientX-r.left)*1280/r.width,y:(e.clientY-r.top)*800/r.height});};
$('send').onclick=()=>{send({type:'text',text:$('input').value});$('input').value='';};
for(const [id,key] of [['tab','Tab'],['enter','Enter'],['back','Backspace']])$(id).onclick=()=>send({type:'key',key});
$('up').onclick=()=>send({type:'scroll',dy:-600});$('down').onclick=()=>send({type:'scroll',dy:600});
$('verify').onclick=()=>send({type:'verify'});$('close').onclick=()=>send({type:'close'});
window.Telegram?.WebApp?.ready();load();
