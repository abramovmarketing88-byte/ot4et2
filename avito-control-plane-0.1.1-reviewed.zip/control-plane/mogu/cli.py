import argparse
import asyncio
import json
from alembic import command
from alembic.config import Config
from sqlalchemy import select
from .config import Settings
from .db import Member, Tenant, database


def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('migrate')
    init=sub.add_parser('bootstrap');init.add_argument('--owner-id',type=int,required=True);init.add_argument('--name',default='Агентство')
    sub.add_parser('doctor')
    args=p.parse_args(); settings=Settings.env()
    settings.state_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
    if args.cmd=='migrate':
        command.upgrade(Config('alembic.ini'),'head')
    elif args.cmd=='bootstrap':
        if args.owner_id<=0:raise SystemExit('Positive numeric Telegram ID required')
        _,sessions=database(settings.database_url)
        with sessions.begin() as s:
            if s.scalar(select(Member).where(Member.telegram_id==args.owner_id)):
                raise SystemExit('Owner already exists; no changes made')
            t=Tenant(name=args.name);s.add(t);s.flush()
            s.add(Member(tenant_id=t.id,telegram_id=args.owner_id,role='owner'))
        print('Owner created. No automatic registration is enabled.')
    elif args.cmd=='doctor':
        print(json.dumps({'bot_token_configured':bool(settings.bot_token),'public_https':settings.public_url.startswith('https://'),
            'postgresql':settings.database_url.startswith('postgresql'),'ui_allowed':settings.ui_allowed,
            'manifest_exists':settings.manifest.exists(),'financial_actions_enabled':False}))


if __name__=='__main__':main()
