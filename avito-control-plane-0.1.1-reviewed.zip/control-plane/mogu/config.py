from dataclasses import dataclass
import os
from pathlib import Path
from urllib.parse import urlsplit


def secret(name: str) -> str:
    path = os.getenv(name + '_FILE')
    return Path(path).read_text().strip() if path else os.getenv(name, '')


@dataclass(frozen=True)
class Settings:
    database_url: str
    bot_token: str
    public_url: str
    state_dir: Path
    manifest: Path
    ui_allowed: bool = False
    headless: bool = True
    chromium_path: str | None = None

    job_timeout_seconds: float = 120

    def __post_init__(self):
        p = urlsplit(self.public_url)
        if p.scheme != 'https' or not p.hostname or p.username or p.password or p.path not in ('', '/') or p.query or p.fragment:
            raise ValueError('PUBLIC_URL must be an HTTPS origin without credentials or path')
        if not 0 < self.job_timeout_seconds <= 900:
            raise ValueError('invalid_job_timeout')

    @classmethod
    def env(cls) -> 'Settings':
        return cls(os.getenv('DATABASE_URL', 'sqlite:///state/local.db'), secret('BOT_TOKEN'),
                   os.getenv('PUBLIC_URL', 'https://localhost'), Path(os.getenv('STATE_DIR', 'state')),
                   Path(os.getenv('SCENARIO_MANIFEST', 'scenarios/avito.json')),
                   os.getenv('AVITO_UI_ALLOWED') == 'true', os.getenv('HEADLESS', 'true') == 'true', os.getenv('CHROMIUM_PATH') or None)
