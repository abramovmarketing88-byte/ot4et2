"""No invented production selectors: deployment supplies a live-verified manifest."""
import json
from urllib.parse import urlsplit


class ScenarioError(Exception):
    pass


class AuthRequired(ScenarioError):
    pass


class HumanRequired(ScenarioError):
    pass


class AvitoAdapter:
    def __init__(self, page, manifest, allowed=False):
        self.page = page
        self.m = manifest
        if not allowed or manifest.get('verified_live') is not True or not manifest.get('tested_at'):
            raise ScenarioError('live_scenario_not_verified')

    async def unique(self, selector):
        if not isinstance(selector, str) or not selector.strip():
            raise ScenarioError('missing_verified_locator')
        loc = self.page.locator(selector)
        if await loc.count() != 1:
            raise ScenarioError('ambiguous_or_missing_locator')
        return loc

    def assert_origin(self, url: str) -> None:
        p = urlsplit(url)
        if p.scheme != 'https' or p.hostname != 'www.avito.ru' or p.username or p.password or p.port not in (None, 443):
            raise ScenarioError('route_not_allowed')

    async def auth(self, account_id: str) -> None:
        self.assert_origin(self.page.url)
        if await self.page.locator(self.m['challenge']).count():
            raise HumanRequired('manual_challenge_required')
        if await self.page.locator(self.m['login_required']).count():
            raise AuthRequired('login_required')
        loc = await self.unique(self.m['identity'])
        if await loc.get_attribute(self.m['identity_attribute']) != account_id:
            raise ScenarioError('wrong_avito_account')

    async def go(self, url: str) -> None:
        if not isinstance(url, str):
            raise ScenarioError('missing_verified_route')
        self.assert_origin(url)
        await self.page.goto(url, wait_until='domcontentloaded', timeout=30000)
        self.assert_origin(self.page.url)

    async def clients(self, account_id: str) -> list[dict]:
        await self.go(self.m['agency_url'])
        await self.auth(account_id)
        rows = self.page.locator(self.m['client_row'])
        out = []
        for row in await rows.all():
            cid = await row.get_attribute(self.m['client_id_attribute'])
            if not cid or cid in [x['id'] for x in out]:
                raise ScenarioError('missing_or_duplicate_client_id')
            out.append({'id': cid, 'name': (await row.inner_text())[:200]})
        if not out:
            await self.unique(self.m['clients_empty'])
        return out

    async def switch(self, account_id: str, client_id: str) -> None:
        await self.clients(account_id)
        matches = []
        for row in await self.page.locator(self.m['client_row']).all():
            if await row.get_attribute(self.m['client_id_attribute']) == client_id:
                matches.append(row)
        if len(matches) != 1:
            raise ScenarioError('exact_client_not_found')
        button = matches[0].get_by_role('button', name=self.m['switch_button'], exact=True)
        if await button.count() != 1:
            raise ScenarioError('ambiguous_switch')
        await button.click(timeout=15000)
        await self.page.locator(self.m['context']).wait_for(timeout=15000)
        from playwright.async_api import expect
        await expect(await self.unique(self.m['context'])).to_have_attribute(self.m['context_attribute'], client_id, timeout=15000)
        await self.context(account_id, client_id)

    async def context(self, account_id: str, client_id: str) -> None:
        await self.auth(account_id)
        loc = await self.unique(self.m['context'])
        if await loc.get_attribute(self.m['context_attribute']) != client_id:
            raise ScenarioError('wrong_client_context')

    async def ads(self, account_id: str, client_id: str) -> dict:
        await self.go(self.m['ads_url'])
        await self.context(account_id, client_id)
        out = []
        for row in await self.page.locator(self.m['ad_row']).all():
            aid = await row.get_attribute(self.m['ad_id_attribute'])
            if not aid or aid in [x['id'] for x in out]:
                raise ScenarioError('invalid_ad_id')
            status = await row.get_attribute(self.m['ad_status_attribute'])
            out.append({'id': aid, 'status': status, 'title': (await row.inner_text())[:200]})
        if not out:
            await self.unique(self.m['ads_empty'])
        await self.context(account_id, client_id)
        return {'items': out, 'scope': 'current_page', 'complete_inventory': False}

    async def execute(self, action: str, account_id: str, client_id: str) -> dict:
        if action == 'clients':
            return {'clients': await self.clients(account_id)}
        await self.switch(account_id, client_id)
        if action in ('status', 'switch'):
            return {'client_id': client_id, 'authenticated': True, 'context_verified': True}
        ads = await self.ads(account_id, client_id)
        if action == 'ads':
            return ads
        if action == 'mogu_preview':
            return {**ads, 'items': ads['items'][:5], 'truncated': len(ads['items']) > 5, 'dry_run': True, 'eligible': None, 'price_minor': None,
                    'max_items': 5, 'budget_minor': 0, 'changed': 0,
                    'reason': 'mogu_ui_price_and_rules_not_verified', 'confirmation_available': False}
        raise ScenarioError('unsupported_action')
