import asyncio
import time
import json
import logging
from sqlalchemy import select, update
from .adapter import AuthRequired, HumanRequired, ScenarioError
from .db import Cabinet, Identity, Job, Tenant
from .locks import Busy
from .security import Denied, cabinet_access
from .service import ACTIONS, TERMINAL


class Cancelled(Exception):
    pass


class Worker:
    def __init__(self, service, browsers):
        self.service, self.browsers = service, browsers
        self.sessions = service.sessions
        self.heartbeat = 0.0

    def check(self, jid):
        with self.sessions() as s:
            j = s.get(Job, jid)
            if not j or j.action not in ACTIONS:
                raise Denied('unsupported_action')
            if j.state == 'CANCEL_REQUESTED' or s.get(Tenant, j.tenant_id).stopped:
                raise Cancelled()
            _, cabinet, _ = cabinet_access(s, j.actor_id, j.cabinet_id, j.action == 'mogu_preview')
            if cabinet.tenant_id != j.tenant_id:
                raise Denied('tenant_mismatch')

    def recover(self):
        # Call only after acquiring the global worker lock; no live worker can be taken over.
        with self.sessions.begin() as s:
            for j in s.scalars(select(Job).where(Job.state.in_(['RUNNING','PREVIEWING','VERIFYING','CANCEL_REQUESTED']))):
                j.state = 'CANCELLED' if j.state == 'CANCEL_REQUESTED' else ('QUEUED' if j.action in ACTIONS else 'UNKNOWN')
                j.notified = False
                j.checkpoint = 'recovered_read' if j.state == 'QUEUED' else 'manual_reconciliation_required'

    def claim(self):
        with self.sessions.begin() as s:
            j = s.scalar(select(Job).where(Job.state == 'QUEUED').order_by(Job.created_at).with_for_update(skip_locked=True).limit(1))
            if not j:
                return None
            n = s.execute(update(Job).where(Job.id == j.id, Job.state == 'QUEUED').values(state='RUNNING', updated_at=int(time.time()))).rowcount
            return j.id if n else None

    def finish(self, jid, state, result):
        with self.sessions.begin() as s:
            j = s.scalar(select(Job).where(Job.id == jid).with_for_update())
            j.notified = False
            j.state = 'CANCELLED' if j.state == 'CANCEL_REQUESTED' else state
            j.result = result
            j.updated_at = int(time.time())
            j.checkpoint = 'completed'
            if j.state in ('WAITING_AUTH', 'WAITING_HUMAN'):
                c = s.get(Cabinet, j.cabinet_id)
                s.get(Identity, c.identity_id).auth_state = state
            logging.info(json.dumps({'event': 'job_finished', 'job_id': jid, 'state': j.state}))
            self.service.audit(s, j.tenant_id, j.actor_id, 'job_' + j.state.lower(), j.id)

    async def tick(self):
        self.heartbeat = time.time()
        jid = self.claim()
        if not jid:
            return False
        started = time.monotonic()
        try:
            timeout = getattr(getattr(self.browsers, 'settings', None), 'job_timeout_seconds', 120)
            async with asyncio.timeout(timeout):
                result, action, actor_id, iid = await self.execute_job(jid)
            if action == 'clients':
                allowed = {x['external_id'] for x in self.service.cabinets(actor_id) if x['identity_id'] == iid}
                result['clients'] = [x for x in result['clients'] if x['id'] in allowed]
            result['duration_ms'] = round((time.monotonic() - started) * 1000)
            result['llm_calls'] = 0
            result['tokens'] = 0
            self.finish(jid, 'SUCCEEDED', result)
        except TimeoutError:
            self.finish(jid, 'FAILED', {'reason': 'job_timeout', 'changed': 0})
        except AuthRequired:
            self.finish(jid, 'WAITING_AUTH', {'reason': 'login_required'})
        except HumanRequired:
            self.finish(jid, 'WAITING_HUMAN', {'reason': 'manual_challenge_required'})
        except (Cancelled, Denied):
            self.finish(jid, 'CANCELLED', {'reason': 'cancelled_or_permission_revoked'})
        except Busy:
            self.finish(jid, 'QUEUED', {'reason': 'profile_busy'})
        except ScenarioError as e:
            self.finish(jid, 'FAILED', {'reason': str(e)})
        except Exception:
            self.finish(jid, 'FAILED', {'reason': 'browser_or_infrastructure_error', 'changed': 0})
        return True

    async def execute_job(self, jid):
        self.check(jid)
        with self.sessions() as s:
            j = s.get(Job, jid)
            _, c, identity = cabinet_access(s, j.actor_id, j.cabinet_id)
            action, account_id, client_id, iid = j.action, identity.account_id, c.external_id, identity.id
        async with self.browsers.open(iid) as page:
            self.check(jid)
            operation = asyncio.create_task(self.browsers.adapter(page).execute(action, account_id, client_id))
            try:
                while not operation.done():
                    self.check(jid)
                    await asyncio.wait({operation}, timeout=.25)
                result = await operation
                self.check(jid)
            finally:
                if not operation.done():
                    operation.cancel()
                await asyncio.gather(operation, return_exceptions=True)
        return result, action, j.actor_id, iid


    async def run(self):
        from .locks import profile_lock
        async with profile_lock(self.browsers.engine, self.browsers.settings.state_dir / 'locks', 'worker-global') as lease:
            self.recover()
            parent = asyncio.current_task()
            async def beat():
                while True:
                    try:
                        if lease:
                            lease.check()
                    except Exception:
                        self.heartbeat = 0
                        parent.cancel()
                        return
                    self.heartbeat = time.time()
                    await asyncio.sleep(2)
            task = asyncio.create_task(beat())
            try:
                while True:
                    await self.tick()
                    await asyncio.sleep(1)
            finally:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
                self.heartbeat = 0
