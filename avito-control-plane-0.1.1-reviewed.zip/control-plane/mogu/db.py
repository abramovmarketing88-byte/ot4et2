from __future__ import annotations
import time
import uuid
from sqlalchemy import BigInteger, Boolean, ForeignKey, Integer, JSON, String, Text, UniqueConstraint, create_engine, event
from sqlalchemy.engine import make_url
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker


def ident() -> str:
    return uuid.uuid4().hex


class Base(DeclarativeBase):
    pass


class Tenant(Base):
    __tablename__ = 'tenants'
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    name: Mapped[str] = mapped_column(String(200))
    access_version: Mapped[int] = mapped_column(Integer, default=1, server_default='1')
    stopped: Mapped[bool] = mapped_column(Boolean, default=False)
    daily_limit_minor: Mapped[int] = mapped_column(BigInteger, default=0)


class Member(Base):
    __tablename__ = 'memberships'
    __table_args__ = (UniqueConstraint('tenant_id', 'telegram_id'),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    access_version: Mapped[int] = mapped_column(Integer, default=1, server_default='1')
    role: Mapped[str] = mapped_column(String(20))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Identity(Base):
    __tablename__ = 'avito_identities'
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    owner_id: Mapped[int] = mapped_column(BigInteger)
    account_id: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(200))
    auth_state: Mapped[str] = mapped_column(String(30), default='UNVERIFIED')


class Cabinet(Base):
    __tablename__ = 'cabinets'
    __table_args__ = (UniqueConstraint('identity_id', 'external_id'),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    identity_id: Mapped[str] = mapped_column(ForeignKey('avito_identities.id'))
    external_id: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(200))


class Permission(Base):
    __tablename__ = 'cabinet_permissions'
    __table_args__ = (UniqueConstraint('member_id', 'cabinet_id'),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    member_id: Mapped[str] = mapped_column(ForeignKey('memberships.id'))
    cabinet_id: Mapped[str] = mapped_column(ForeignKey('cabinets.id'))
    execute: Mapped[bool] = mapped_column(Boolean, default=False)


class Job(Base):
    __tablename__ = 'jobs'
    __table_args__ = (UniqueConstraint('tenant_id', 'request_key'),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    actor_id: Mapped[int] = mapped_column(BigInteger)
    cabinet_id: Mapped[str] = mapped_column(ForeignKey('cabinets.id'))
    request_key: Mapped[str] = mapped_column(String(200))
    action: Mapped[str] = mapped_column(String(40))
    state: Mapped[str] = mapped_column(String(40), default='QUEUED', index=True)
    checkpoint: Mapped[str] = mapped_column(String(100), default='created')
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[int] = mapped_column(BigInteger, default=lambda: int(time.time()))
    updated_at: Mapped[int] = mapped_column(BigInteger, default=lambda: int(time.time()))
    notified: Mapped[bool] = mapped_column(Boolean, default=False)


class LoginGrant(Base):
    __tablename__ = 'login_grants'
    digest: Mapped[str] = mapped_column(String(64), primary_key=True)
    member_version: Mapped[int] = mapped_column(Integer, default=1, server_default='1')
    tenant_version: Mapped[int] = mapped_column(Integer, default=1, server_default='1')
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    actor_id: Mapped[int] = mapped_column(BigInteger)
    identity_id: Mapped[str] = mapped_column(ForeignKey('avito_identities.id'))
    expires_at: Mapped[int] = mapped_column(BigInteger)
    used: Mapped[bool] = mapped_column(Boolean, default=False)


class Audit(Base):
    __tablename__ = 'audit_events'
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=ident)
    tenant_id: Mapped[str] = mapped_column(ForeignKey('tenants.id'))
    actor_id: Mapped[int] = mapped_column(BigInteger)
    event: Mapped[str] = mapped_column(String(80))
    object_id: Mapped[str] = mapped_column(String(100))
    at: Mapped[int] = mapped_column(BigInteger, default=lambda: int(time.time()))


def database(url: str):
    args = {'check_same_thread': False, 'timeout': 5} if url.startswith('sqlite') else {}
    if url.startswith('postgresql'):
        options = make_url(url).query.get('options', '')
        args = {'connect_timeout': 5, 'options': options + ' -c statement_timeout=3000 -c lock_timeout=2000'}
    engine = create_engine(url, pool_pre_ping=True, connect_args=args,
                           **({'pool_timeout': 5} if not url.startswith('sqlite://') or url.startswith('sqlite:///') else {}))
    if engine.dialect.name == 'sqlite':
        @event.listens_for(engine, 'connect')
        def foreign_keys(connection, _):
            connection.execute('PRAGMA foreign_keys=ON')
    return engine, sessionmaker(engine, expire_on_commit=False)
