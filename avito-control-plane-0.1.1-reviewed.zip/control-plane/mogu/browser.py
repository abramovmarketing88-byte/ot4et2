import asyncio
from contextlib import asynccontextmanager
import json
import os
import re
from playwright.async_api import async_playwright
from sqlalchemy import text
from .adapter import AvitoAdapter
from .locks import Busy, profile_lock


class BrowserManager:
    def __init__(self, settings, engine):
        self.settings, self.engine = settings, engine
        self.gate = asyncio.Lock()  # Pilot: at most one active browser, including manual login.
        self.active = False

    def manifest(self):
        return json.loads(self.settings.manifest.read_text())

    @asynccontextmanager
    async def open(self, identity_id, *, wait=True):
        if not re.fullmatch(r'[a-f0-9]{32}', identity_id):
            raise ValueError('invalid_identity_id')
        # No await between this check and uncontended Lock.acquire: one event loop owner.
        if not wait and self.gate.locked():
            raise Busy('browser_busy')
        async with self.gate:
            async with profile_lock(self.engine, self.settings.state_dir / 'locks', identity_id) as lease:
                root = self.settings.state_dir / 'profiles' / identity_id
                root.mkdir(parents=True, exist_ok=True, mode=0o700)
                os.chmod(root, 0o700)
                async with async_playwright() as p:
                    context = await p.chromium.launch_persistent_context(str(root), headless=self.settings.headless,
                              chromium_sandbox=True, executable_path=self.settings.chromium_path, viewport={'width': 1280, 'height': 800}, accept_downloads=False)
                    self.active = True
                    task = asyncio.create_task(self.watch_db(lease, context)) if lease else None
                    try:
                        page = context.pages[0] if context.pages else await context.new_page()
                        page.set_default_timeout(15000)
                        yield page
                    finally:
                        if task:
                            task.cancel()
                            await asyncio.gather(task, return_exceptions=True)
                        await context.close()
                        self.active = False

    async def watch_db(self, lease, context):
        while True:
            await asyncio.sleep(1)
            try:
                lease.check()
            except Exception:
                await context.close()  # No new browser owner while old process can continue clicking.
                return

    def adapter(self, page):
        return AvitoAdapter(page, self.manifest(), self.settings.ui_allowed)
