"""Deterministic Avito operations. No LLM dependency."""
