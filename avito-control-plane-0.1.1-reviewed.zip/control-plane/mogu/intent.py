"""Deliberately small grammar; free text never becomes arbitrary browser code."""
import re


def parse(text: str):
    t = text.strip().lower()
    patterns = [('status', r'(?:проверь статус кабинета|статус)\s+([a-f0-9]{32})'),
                ('ads', r'(?:покажи объявления|объявления)\s+([a-f0-9]{32})'),
                ('mogu_preview', r'(?:подготовь могу сегодня|могу сегодня)\s+([a-f0-9]{32})')]
    for action, pattern in patterns:
        m = re.fullmatch(pattern, t)
        if m:
            return action, m[1]
    return None
