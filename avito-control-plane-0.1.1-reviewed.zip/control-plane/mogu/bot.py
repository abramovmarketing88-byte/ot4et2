import asyncio
import json
import logging
from aiogram import Bot, Dispatcher, F
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from sqlalchemy import select, update
from .config import Settings
from .db import Audit, Job, Member, database
from .intent import parse
from .security import Denied, admin, membership
from .service import Service, TERMINAL


def keyboard(rows):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=d) for t,d in row] for row in rows])


def main_menu(settings):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Мои кабинеты / Выбрать клиента', callback_data='cabinets')],
        [InlineKeyboardButton(text='Статус задач / История', callback_data='jobs')],
        [InlineKeyboardButton(text='Подключить / восстановить Авито', web_app=WebAppInfo(url=settings.public_url))],
        [InlineKeyboardButton(text='Настройки / Администрирование', callback_data='settings')]])


def create_dispatcher(service, settings, bot):
    sessions = service.sessions
    dp = Dispatcher()

    async def respond(event, uid, command, key):
        try:
            if command in ('/start', '/help', 'menu'):
                with sessions() as s:
                    membership(s, uid)
                await event.answer('Выберите кабинет и действие.', reply_markup=main_menu(settings))
            elif command == 'cabinets':
                rows = service.cabinets(uid)
                await event.answer('Доступные кабинеты:' if rows else 'Нет назначенных кабинетов.',
                    reply_markup=keyboard([[(f"{c['name']} · {c['external_id']}", 'cab:'+c['id'])] for c in rows]) if rows else None)
            elif command.startswith('cab:'):
                cid=command[4:]
                c=next((x for x in service.cabinets(uid) if x['id']==cid),None)
                if not c: raise Denied('cabinet_denied')
                rows=[[(label, 'do:'+action+':'+cid)] for label,action in [('Проверить статус','status'),('Показать клиентов','clients'),('Проверить переключение','switch'),('Объявления','ads'),('Могу сегодня — предварительный просмотр','mogu_preview')]]
                await event.answer(f"Клиент: {c['name']}\nID: {c['external_id']}\nАвторизация: {c['auth_state']}",reply_markup=keyboard(rows))
            elif command.startswith('do:'):
                _, action,cid=command.split(':')
                jid=service.submit(uid,cid,action,key)
                await event.answer('Задача принята: '+jid,reply_markup=keyboard([[('Остановить','cancel:'+jid)],[('Обновить статусы','jobs')]]))
            elif command.startswith('cancel:'):
                service.cancel(uid,command[7:]);await event.answer('Остановка запрошена.')
            elif command == 'jobs':
                jobs=service.jobs(uid)
                await event.answer(('\n\n'.join(j['id']+' · '+j['action']+' · '+j['state']+'\n'+json.dumps(j['result'],ensure_ascii=False) for j in jobs) or 'Задач нет.')[:4000])
            elif command == 'settings':
                with sessions() as s: m=membership(s,uid)
                text='Роль: '+m.role+'\nЛимит расходов: 0 ₽. Изменения Авито заблокированы.'
                if m.role in ('owner','admin'):
                    text+='\n\nКоманды:\n/member TG_ID operator|observer|admin\n/revoke TG_ID\n/identity ACCOUNT_ID Название\n/cabinet ID_АВТОРИЗАЦИИ CLIENT_ID Название\n/grant TG_ID CABINET_ID read|execute\n/team\n/audit\n/kill on|off (владелец)'
                await event.answer(text)
            elif command.startswith('/'):
                parts=command.split(); op=parts[0]
                if op=='/member' and len(parts)==3: service.add_member(uid,int(parts[1]),parts[2])
                elif op=='/revoke' and len(parts)==2: service.revoke(uid,int(parts[1]))
                elif op=='/identity' and len(parts)>=3:
                    await event.answer('Авторизация: '+service.add_identity(uid,parts[1],' '.join(parts[2:])));return
                elif op=='/cabinet' and len(parts)>=4:
                    await event.answer('Кабинет: '+service.add_cabinet(uid,parts[1],parts[2],' '.join(parts[3:])));return
                elif op=='/grant' and len(parts)==4 and parts[3] in ('read','execute'): service.grant(uid,int(parts[1]),parts[2],parts[3]=='execute')
                elif op=='/kill' and len(parts)==2 and parts[1] in ('on','off'): service.stop(uid,parts[1]=='on')
                elif op in ('/team','/audit'):
                    with sessions() as s:
                        m=admin(s,uid)
                        if op=='/team': out=[f'{x.telegram_id} {x.role} active={x.active}' for x in s.scalars(select(Member).where(Member.tenant_id==m.tenant_id))]
                        else: out=[f'{x.at} {x.actor_id} {x.event} {x.object_id}' for x in s.scalars(select(Audit).where(Audit.tenant_id==m.tenant_id).order_by(Audit.at.desc()).limit(20))]
                    await event.answer('\n'.join(out)[:4000] or 'Нет записей');return
                else: raise Denied('unknown_command')
                await event.answer('Сохранено.')
            else:
                intent=parse(command)
                if not intent:
                    await event.answer('Команда не распознана. Выберите действие в меню или отправьте «статус ID_КАБИНЕТА».');return
                jid=service.submit(uid,intent[1],intent[0],key)
                await event.answer('Задача принята: '+jid)
        except IntegrityError:
            await event.answer('Запись уже существует или данные некорректны. Проверьте список кабинетов.')
        except SQLAlchemyError:
            await event.answer('База данных временно недоступна. Повторите позже.')
        except (Denied, ValueError):
            await event.answer('Нет доступа или команда некорректна. Для доступа сообщите администратору ваш Telegram ID: '+str(uid))

    @dp.message(F.chat.type == 'private')
    async def message(m):
        await respond(m,m.from_user.id,m.text or '',f'message:{m.chat.id}:{m.message_id}')

    @dp.callback_query()
    async def callback(q):
        await q.answer()
        if not q.message or q.message.chat.type!='private':return
        await respond(q.message,q.from_user.id,q.data or '',f'callback:{q.from_user.id}:{q.message.message_id}:{q.data}')

    async def notify():
        while True:
            try:
                with sessions() as s:
                    pending=list(s.scalars(select(Job).where(Job.notified.is_(False),Job.state.in_(list(TERMINAL|{'WAITING_AUTH','WAITING_HUMAN'}))).limit(20)))
                for j in pending:
                    try:
                        # Revocation must also prevent disclosure in outbound notifications.
                        from .security import cabinet_access
                        with sessions() as s: cabinet_access(s,j.actor_id,j.cabinet_id)
                        await bot.send_message(j.actor_id,f'Задача {j.id}\n{j.state}\n'+json.dumps(j.result,ensure_ascii=False)[:3000])
                    except Denied:
                        pass
                    except Exception:
                        continue
                    with sessions.begin() as s:
                        s.execute(update(Job).where(Job.id == j.id, Job.state == j.state, Job.updated_at == j.updated_at).values(notified=True))
            except Exception:
                logging.error('{"event":"notification_cycle_failed"}')
            await asyncio.sleep(3)

    return dp, notify


async def run():
    settings = Settings.env()
    if not settings.bot_token:
        raise RuntimeError("BOT_TOKEN_FILE or BOT_TOKEN is required")
    _, sessions = database(settings.database_url)
    service = Service(sessions)
    bot = Bot(settings.bot_token)
    dp, notify = create_dispatcher(service, settings, bot)

    task=asyncio.create_task(notify())
    try:
        await dp.start_polling(bot)
    finally:
        task.cancel();await asyncio.gather(task,return_exceptions=True);await bot.session.close()


if __name__=='__main__':
    asyncio.run(run())
