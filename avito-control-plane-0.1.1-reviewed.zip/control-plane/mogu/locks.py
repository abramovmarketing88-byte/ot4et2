"""Process and PostgreSQL session locks; never reassign a live owner's profile."""
from contextlib import asynccontextmanager
from dataclasses import dataclass
import fcntl
import hashlib
import re
from sqlalchemy import text


class Busy(Exception):
    pass


@dataclass
class ProfileLease:
    connection: object
    key: int
    backend_pid: int

    def check(self) -> None:
        # An automatically reconnected DB session no longer owns the old advisory lock.
        pid = self.connection.scalar(text('SELECT pg_backend_pid()'))
        self.connection.commit()
        if pid != self.backend_pid:
            raise RuntimeError('lock_session_changed')


@asynccontextmanager
async def profile_lock(engine, root, identity_id):
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}', identity_id):
        raise ValueError('invalid_lock_id')
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    f = (root / (identity_id + '.lock')).open('a')
    connection = None
    acquired = False
    lease = None
    try:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Busy('profile_busy') from None
        if engine.dialect.name == 'postgresql':
            connection = engine.connect()
            key = int.from_bytes(hashlib.sha256(identity_id.encode()).digest()[:8], 'big', signed=True)
            acquired = bool(connection.scalar(text('SELECT pg_try_advisory_lock(:key)'), {'key': key}))
            pid = connection.scalar(text('SELECT pg_backend_pid()'))
            # Session locks survive COMMIT; do not leave an idle transaction open.
            connection.commit()
            if not acquired:
                raise Busy('profile_busy')
            lease = ProfileLease(connection, key, pid)
        yield lease
    finally:
        if connection is not None:
            try:
                if acquired and not connection.invalidated:
                    connection.execute(text('SELECT pg_advisory_unlock(:key)'), {'key': key})
                    connection.commit()
            except Exception:
                connection.invalidate()
            connection.close()
        f.close()
