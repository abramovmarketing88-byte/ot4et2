"""All transports call the same authorization and transaction boundary."""
import hashlib
import secrets
import time
from sqlalchemy import select, update, func, delete
from sqlalchemy.exc import IntegrityError
from .db import Audit, Cabinet, Identity, Job, LoginGrant, Member, Permission, Tenant
from .security import Denied, admin, cabinet_access, identity_access, membership

ACTIONS = {'status', 'clients', 'switch', 'ads', 'mogu_preview'}
TERMINAL = {'SUCCEEDED', 'PARTIAL', 'FAILED', 'UNKNOWN', 'CANCELLED'}
STATES = {'CREATED', 'PREVIEWING', 'AWAITING_CONFIRMATION', 'QUEUED', 'RUNNING', 'VERIFYING',
          *TERMINAL, 'WAITING_AUTH', 'WAITING_HUMAN', 'CANCEL_REQUESTED'}


class Service:
    def __init__(self, sessions):
        self.sessions = sessions

    def audit(self, s, tenant, uid, event, obj):
        s.add(Audit(tenant_id=tenant, actor_id=uid, event=event, object_id=obj))

    def cabinets(self, uid: int) -> list[dict]:
        with self.sessions() as s:
            m = membership(s, uid)
            result = []
            for c in s.scalars(select(Cabinet).where(Cabinet.tenant_id == m.tenant_id)):
                try:
                    _, _, i = cabinet_access(s, uid, c.id)
                    result.append({'id': c.id, 'name': c.name, 'external_id': c.external_id,
                                   'identity_id': i.id, 'auth_state': i.auth_state})
                except Denied:
                    continue
            return result

    def submit(self, uid: int, cid: str, action: str, key: str) -> str:
        if action not in ACTIONS:
            raise Denied('unsupported_action')
        with self.sessions.begin() as s:
            m, c, _ = cabinet_access(s, uid, cid, execute=action == 'mogu_preview')
            if s.get(Tenant, m.tenant_id).stopped:
                raise Denied('system_stopped')
            old = s.scalar(select(Job).where(Job.tenant_id == m.tenant_id, Job.request_key == key))
            if old:
                if (old.actor_id, old.cabinet_id, old.action) != (uid, cid, action):
                    raise Denied('idempotency_conflict')
                return old.id
            tenant_id = m.tenant_id
            s.scalar(select(Member).where(Member.id == m.id).with_for_update())
            count = s.scalar(select(func.count()).select_from(Job).where(Job.tenant_id == m.tenant_id, Job.actor_id == uid, Job.state.in_(['QUEUED','RUNNING','WAITING_AUTH','WAITING_HUMAN'])))
            if count >= 10:
                raise Denied('queue_limit')
            j = Job(tenant_id=m.tenant_id, actor_id=uid, cabinet_id=cid, action=action, request_key=key)
            s.add(j)
            try:
                s.flush()
            except IntegrityError:
                s.rollback()
                with self.sessions() as retry:
                    existing = retry.scalar(select(Job).where(Job.tenant_id == tenant_id, Job.request_key == key))
                    if not existing or (existing.actor_id, existing.cabinet_id, existing.action) != (uid, cid, action):
                        raise Denied('invalid_or_conflicting_job') from None
                    return existing.id
            self.audit(s, m.tenant_id, uid, 'job_created', j.id)
            return j.id

    def jobs(self, uid: int) -> list[dict]:
        with self.sessions() as s:
            m = membership(s, uid)
            q = select(Job).where(Job.tenant_id == m.tenant_id).order_by(Job.created_at.desc()).limit(30)
            out = []
            for j in s.scalars(q):
                try:
                    cabinet_access(s, uid, j.cabinet_id)
                    out.append({'id': j.id, 'action': j.action, 'state': j.state, 'result': j.result})
                except Denied:
                    pass
            return out

    def cancel(self, uid: int, jid: str) -> None:
        with self.sessions.begin() as s:
            j = s.scalar(select(Job).where(Job.id == jid).with_for_update())
            if not j:
                raise Denied('job_denied')
            m, _, _ = cabinet_access(s, uid, j.cabinet_id)
            if j.actor_id != uid and m.role not in ('owner', 'admin'):
                raise Denied('job_denied')
            if j.state not in TERMINAL:
                j.state = 'CANCEL_REQUESTED' if j.state in ('RUNNING', 'VERIFYING', 'PREVIEWING') else 'CANCELLED'
                self.audit(s, j.tenant_id, uid, 'job_cancel', j.id)

    def add_member(self, uid: int, telegram_id: int, role: str) -> None:
        if type(telegram_id) is not int or telegram_id <= 0:
            raise Denied('invalid_telegram_id')
        if role not in ('admin', 'operator', 'observer'):
            raise Denied('invalid_role')
        with self.sessions.begin() as s:
            m = admin(s, uid, owner_only=role == 'admin')
            other = s.scalar(select(Member).where(Member.tenant_id == m.tenant_id, Member.telegram_id == telegram_id).with_for_update())
            if other and other.role == 'admin' and m.role != 'owner':
                raise Denied('owner_required')
            if other and other.role == 'owner':
                raise Denied('owner_protected')
            if other:
                if other.role != role or not other.active:
                    self.invalidate_member(s, other)
                other.role, other.active = role, True
            else:
                s.add(Member(tenant_id=m.tenant_id, telegram_id=telegram_id, role=role))
            self.audit(s, m.tenant_id, uid, 'member_added', str(telegram_id))

    def revoke(self, uid: int, telegram_id: int) -> None:
        with self.sessions.begin() as s:
            m = admin(s, uid)
            other = s.scalar(select(Member).where(Member.tenant_id == m.tenant_id, Member.telegram_id == telegram_id).with_for_update())
            if not other or other.role == 'owner' or (other.role == 'admin' and m.role != 'owner'):
                raise Denied('cannot_revoke')
            self.invalidate_member(s, other)
            other.active = False
            self.audit(s, m.tenant_id, uid, 'member_revoked', str(telegram_id))

    def grant(self, uid: int, telegram_id: int, cid: str, execute: bool = False) -> None:
        with self.sessions.begin() as s:
            m = admin(s, uid)
            _, c, _ = cabinet_access(s, uid, cid)
            target = membership(s, telegram_id, m.tenant_id)
            if c.tenant_id != m.tenant_id:
                raise Denied('tenant_mismatch')
            p = s.scalar(select(Permission).where(Permission.member_id == target.id, Permission.cabinet_id == cid))
            if p:
                p.execute = execute
            else:
                s.add(Permission(member_id=target.id, cabinet_id=cid, execute=execute))
            self.audit(s, m.tenant_id, uid, 'permission_granted', target.id + ':' + cid)

    def add_identity(self, uid: int, account_id: str, name: str) -> str:
        with self.sessions.begin() as s:
            m = admin(s, uid)
            i = Identity(tenant_id=m.tenant_id, owner_id=uid, account_id=account_id, name=name)
            s.add(i); s.flush()
            self.audit(s, m.tenant_id, uid, 'identity_added', i.id)
            return i.id

    def add_cabinet(self, uid: int, iid: str, external_id: str, name: str) -> str:
        with self.sessions.begin() as s:
            m = admin(s, uid)
            _, i = identity_access(s, uid, iid)
            if i.tenant_id != m.tenant_id:
                raise Denied('tenant_mismatch')
            c = Cabinet(tenant_id=m.tenant_id, identity_id=iid, external_id=external_id, name=name)
            s.add(c); s.flush()
            self.audit(s, m.tenant_id, uid, 'cabinet_added', c.id)
            return c.id

    def stop(self, uid: int, enabled: bool = True) -> None:
        with self.sessions.begin() as s:
            m = admin(s, uid, owner_only=True)
            t = s.scalar(select(Tenant).where(Tenant.id == m.tenant_id).with_for_update())
            t.stopped = enabled
            if enabled:
                t.access_version += 1
                s.execute(update(LoginGrant).where(LoginGrant.tenant_id == m.tenant_id).values(used=True))
                self.cancel_pending(s, m.tenant_id)
            self.audit(s, m.tenant_id, uid, 'kill_switch', str(enabled))

    def login_grant(self, uid: int, iid: str) -> str:
        token = secrets.token_urlsafe(32)
        with self.sessions.begin() as s:
            m, _ = identity_access(s, uid, iid)
            if s.get(Tenant, m.tenant_id).stopped:
                raise Denied('system_stopped')
            recent = s.scalar(select(func.count()).select_from(Audit).where(Audit.tenant_id == m.tenant_id, Audit.actor_id == uid, Audit.event == 'login_grant', Audit.at > int(time.time()) - 60))
            if recent >= 3:
                raise Denied('login_rate_limit')
            s.add(LoginGrant(digest=hashlib.sha256(token.encode()).hexdigest(), tenant_id=m.tenant_id,
                             actor_id=uid, identity_id=iid, expires_at=int(time.time()) + 120,
                             member_version=m.access_version, tenant_version=s.get(Tenant, m.tenant_id).access_version))
            self.audit(s, m.tenant_id, uid, 'login_grant', iid)
        return token

    def consume_grant(self, uid: int, token: str, *, with_stamp: bool = False):
        digest = hashlib.sha256(token.encode()).hexdigest()
        with self.sessions.begin() as s:
            g = s.get(LoginGrant, digest)
            if not g or g.actor_id != uid or g.expires_at < time.time():
                raise Denied('grant_invalid')
            m, _ = identity_access(s, uid, g.identity_id)
            tenant = s.get(Tenant, m.tenant_id)
            if (m.access_version, tenant.access_version) != (g.member_version, g.tenant_version):
                raise Denied('grant_revoked')
            if m.tenant_id != g.tenant_id or tenant.stopped:
                raise Denied('system_stopped')
            n = s.execute(update(LoginGrant).where(LoginGrant.digest == digest, LoginGrant.used.is_(False)).values(used=True)).rowcount
            if n != 1:
                raise Denied('grant_consumed')
            if with_stamp:
                return g.identity_id, (m.access_version, s.get(Tenant, m.tenant_id).access_version)
            return g.identity_id

    def cancel_pending(self, s, tenant_id: str, actor_id: int | None = None) -> None:
        criteria = [Job.tenant_id == tenant_id]
        if actor_id is not None:
            criteria.append(Job.actor_id == actor_id)
        s.execute(update(Job).where(*criteria, Job.state.in_(['CREATED','QUEUED','WAITING_AUTH','WAITING_HUMAN','AWAITING_CONFIRMATION'])).values(state='CANCELLED', notified=False, updated_at=int(time.time())))
        s.execute(update(Job).where(*criteria, Job.state.in_(['RUNNING','VERIFYING','PREVIEWING'])).values(state='CANCEL_REQUESTED', notified=False, updated_at=int(time.time())))

    def invalidate_member(self, s, member: Member) -> None:
        member.access_version += 1
        s.execute(update(LoginGrant).where(LoginGrant.tenant_id == member.tenant_id, LoginGrant.actor_id == member.telegram_id).values(used=True))
        s.execute(delete(Permission).where(Permission.member_id == member.id))
        self.cancel_pending(s, member.tenant_id, member.telegram_id)

    def login_stamp(self, uid: int, iid: str, expected: tuple[int, int] | None = None) -> tuple[int, int]:
        with self.sessions() as s:
            m, _ = identity_access(s, uid, iid)
            t = s.get(Tenant, m.tenant_id)
            stamp = (m.access_version, t.access_version)
            if t.stopped or (expected is not None and stamp != expected):
                raise Denied('session_revoked')
            return stamp

    def complete_login(self, uid: int, iid: str, stamp: tuple[int, int], verified: bool) -> None:
        with self.sessions.begin() as s:
            m, identity = identity_access(s, uid, iid)
            t = s.get(Tenant, m.tenant_id)
            if t.stopped or stamp != (m.access_version, t.access_version):
                raise Denied('session_revoked')
            identity.auth_state = 'VERIFIED' if verified else 'UNVERIFIED'
            if verified:
                cabinet_ids = select(Cabinet.id).where(Cabinet.identity_id == iid, Cabinet.tenant_id == m.tenant_id)
                s.execute(update(Job).where(Job.cabinet_id.in_(cabinet_ids), Job.tenant_id == m.tenant_id,
                          Job.state.in_(['WAITING_AUTH','WAITING_HUMAN'])).values(state='QUEUED', notified=False, updated_at=int(time.time())))
            self.audit(s, m.tenant_id, uid, 'login_verified' if verified else 'login_closed', iid)
