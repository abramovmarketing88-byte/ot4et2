import hashlib
import hmac
import json
import re
import time
from urllib.parse import parse_qsl
from sqlalchemy import select
from .db import Cabinet, Identity, Member, Permission, Tenant


class Denied(Exception):
    pass


def validate_init_data(raw: str, bot_token: str, now: int | None = None) -> int:
    if not bot_token or not isinstance(raw, str) or len(raw) > 16384:
        raise Denied('invalid_auth')
    try:
        pairs = parse_qsl(raw, strict_parsing=True, max_num_fields=32)
    except ValueError:
        raise Denied('invalid_auth') from None
    if len({k for k, _ in pairs}) != len(pairs):
        raise Denied('duplicate_auth_field')
    data = dict(pairs)
    supplied = data.pop('hash', '')
    if not re.fullmatch(r'[a-fA-F0-9]{64}', supplied):
        raise Denied('invalid_signature')
    secret = hmac.new(b'WebAppData', bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, '\n'.join(f'{k}={v}' for k, v in sorted(data.items())).encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, supplied.lower()):
        raise Denied('invalid_signature')
    now = int(time.time()) if now is None else now
    try:
        age = now - int(data['auth_date'])
        uid = json.loads(data['user'])['id']
        if age < -30 or age > 300 or type(uid) is not int or uid <= 0:
            raise ValueError
        return uid
    except (ValueError, KeyError, TypeError):
        raise Denied('expired_or_invalid_auth') from None


def membership(s, uid: int, tenant: str | None = None) -> Member:
    q = select(Member).where(Member.telegram_id == uid, Member.active.is_(True))
    if tenant:
        q = q.where(Member.tenant_id == tenant)
    rows = list(s.scalars(q))
    if len(rows) != 1:
        raise Denied('membership_required_or_ambiguous')
    return rows[0]


def cabinet_access(s, uid: int, cabinet_id: str, execute: bool = False):
    c = s.get(Cabinet, cabinet_id)
    if not c:
        raise Denied('cabinet_denied')
    m = membership(s, uid, c.tenant_id)
    identity = s.get(Identity, c.identity_id)
    if not identity or identity.tenant_id != c.tenant_id:
        raise Denied('tenant_mismatch')
    if execute and m.role == 'observer':
        raise Denied('read_only')
    if m.role not in ('owner', 'admin'):
        p = s.scalar(select(Permission).where(Permission.member_id == m.id, Permission.cabinet_id == c.id))
        if not p or (execute and not p.execute):
            raise Denied('cabinet_denied')
    return m, c, identity


def identity_access(s, uid: int, identity_id: str):
    i = s.get(Identity, identity_id)
    if not i:
        raise Denied('identity_denied')
    m = membership(s, uid, i.tenant_id)
    if m.role not in ('owner', 'admin'):
        raise Denied('login_denied')
    if m.role == 'observer':
        raise Denied('read_only')
    return m, i


def admin(s, uid: int, owner_only: bool = False):
    m = membership(s, uid)
    if m.role not in (('owner',) if owner_only else ('owner', 'admin')):
        raise Denied('admin_required')
    return m
