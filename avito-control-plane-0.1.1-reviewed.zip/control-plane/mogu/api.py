import asyncio
import base64
from contextlib import asynccontextmanager
import json
import time
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from sqlalchemy.exc import SQLAlchemyError
from pydantic import BaseModel, Field
from sqlalchemy import select, text
from .browser import BrowserManager
from .config import Settings
from .db import Identity, Job, Tenant, database
from .security import Denied, identity_access, membership, validate_init_data
from .service import Service
from .worker import Worker


class GrantRequest(BaseModel):
    identity_id: str = Field(pattern=r'^[a-f0-9]{32}$')


def create_app(settings=None, service=None, browsers=None, run_worker=True):
    settings = settings or Settings.env()
    settings.state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    engine, sessions = database(settings.database_url) if service is None else (service.sessions.kw['bind'], service.sessions)
    service = service or Service(sessions)
    browsers = browsers or BrowserManager(settings, engine)
    worker = Worker(service, browsers)

    task = None

    @asynccontextmanager
    async def lifespan(app):
        nonlocal task
        task = asyncio.create_task(worker.run()) if run_worker else None
        yield
        if task:
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None)
    app.state.service, app.state.worker = service, worker

    @app.exception_handler(Denied)
    async def denied_handler(request, exc):
        return JSONResponse({'detail': 'access_denied'}, status_code=403)

    @app.exception_handler(SQLAlchemyError)
    async def database_handler(request, exc):
        return JSONResponse({'detail': 'database_unavailable'}, status_code=503)

    @app.middleware('http')
    async def headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.update({'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer',
                                 'X-Content-Type-Options': 'nosniff',
                                 'Content-Security-Policy': "default-src 'self'; script-src 'self' https://telegram.org; connect-src 'self'; img-src 'self' data:; style-src 'self'; frame-ancestors https://web.telegram.org https://*.telegram.org"})
        return response

    def user(raw):
        try:
            uid = validate_init_data(raw, settings.bot_token)
            with sessions() as s:
                membership(s, uid)
            return uid
        except (Denied, ValueError):
            raise HTTPException(403, 'Доступ запрещён') from None

    @app.get('/health/live')
    def live():
        return {'alive': True}

    @app.get('/health/ready')
    def ready():
        try:
            with sessions() as s:
                s.execute(text('SELECT 1'))
                if run_worker and s.scalar(text('SELECT version_num FROM alembic_version')) != '0002':
                    raise RuntimeError('schema_not_current')
            if run_worker and (task is None or task.done() or not worker.heartbeat or time.time() - worker.heartbeat > 15):
                raise RuntimeError()
            return {'database': True, 'worker': bool(worker.heartbeat)}
        except Exception:
            raise HTTPException(503, 'not_ready') from None

    @app.get('/', response_class=HTMLResponse)
    def portal():
        return Path(__file__).with_name('portal.html').read_text()

    @app.get('/portal.js')
    def js():
        from fastapi.responses import Response
        return Response(Path(__file__).with_name('portal.js').read_text(), media_type='text/javascript')

    @app.get('/portal.css')
    def css():
        from fastapi.responses import Response
        return Response('body{font:16px system-ui;margin:16px}#screen{max-width:100%;height:auto}button,input,select{padding:10px;margin:4px}', media_type='text/css')

    @app.get('/api/identities')
    def identities(x_telegram_init_data: str = Header(default='')):
        uid = user(x_telegram_init_data)
        with sessions() as s:
            m = membership(s, uid)
            out = []
            for i in s.scalars(select(Identity).where(Identity.tenant_id == m.tenant_id)):
                try:
                    identity_access(s, uid, i.id)
                    out.append({'id': i.id, 'name': i.name, 'state': i.auth_state})
                except Denied:
                    pass
            return out

    @app.post('/api/login/grant')
    def grant(body: GrantRequest, request: Request, x_telegram_init_data: str = Header(default='')):
        if request.headers.get('origin') != settings.public_url.rstrip('/'):
            raise HTTPException(403, 'origin_denied')
        uid = user(x_telegram_init_data)
        try:
            return {'grant': service.login_grant(uid, body.identity_id), 'expires_in': 120}
        except Denied:
            raise HTTPException(403, 'login_denied') from None

    @app.websocket('/remote')
    async def remote(ws: WebSocket):
        if ws.headers.get('origin') != settings.public_url.rstrip('/'):
            await ws.close(code=1008)
            return
        await ws.accept()

        async def send(payload):
            # A client that stops reading must not hold the browser forever.
            await asyncio.wait_for(ws.send_json(payload), timeout=5)

        async def receive(timeout):
            raw = await asyncio.wait_for(ws.receive_text(), timeout=timeout)
            if len(raw.encode()) > 16384:
                raise Denied('input_too_large')
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise Denied('invalid_input')
            return value

        try:
            first = await receive(10)
            uid = user(first.get('init_data', ''))
            iid, stamp = service.consume_grant(uid, first.get('grant', ''), with_stamp=True)
            async with asyncio.timeout(900), browsers.open(iid, wait=False) as page:
                service.login_stamp(uid, iid, stamp)
                # Existing VERIFIED flags cannot survive an interrupted manual session.
                with sessions.begin() as s:
                    s.get(Identity, iid).auth_state = 'UNVERIFIED'
                await page.goto('https://www.avito.ru/', wait_until='domcontentloaded')
                await send({'status': 'Войдите в Авито в этом окне. Затем нажмите «Проверить вход».'})
                verified = False
                while True:
                    service.login_stamp(uid, iid, stamp)
                    with sessions() as s:
                        account_id = s.get(Identity, iid).account_id
                    frame = base64.b64encode(await page.screenshot(type='jpeg', quality=55)).decode()
                    await send({'frame': frame})
                    try:
                        msg = await receive(.7)
                    except asyncio.TimeoutError:
                        continue
                    # Recheck AFTER waiting for input. Revocation may happen during receive.
                    service.login_stamp(uid, iid, stamp)
                    kind = msg.get('type')
                    if kind == 'click':
                        x, y = float(msg['x']), float(msg['y'])
                        if not 0 <= x < 1280 or not 0 <= y < 800:
                            raise Denied('invalid_coordinates')
                        await page.mouse.click(x, y)
                    elif kind == 'text':
                        if not isinstance(msg.get('text'), str) or len(msg['text']) > 2000:
                            raise Denied('invalid_text')
                        await page.keyboard.insert_text(msg['text'])
                    elif kind == 'key' and msg.get('key') in {'Tab','Enter','Backspace','Escape','ArrowDown','ArrowUp','ArrowLeft','ArrowRight'}:
                        await page.keyboard.press(msg['key'])
                    elif kind == 'scroll':
                        await page.mouse.wheel(0, max(-1000, min(1000, int(msg['dy']))))
                    elif kind == 'verify':
                        try:
                            await browsers.adapter(page).auth(account_id)
                        except Exception:
                            await send({'status': 'Вход не подтверждён: проверьте аккаунт и настройку проверенного сценария.'})
                        else:
                            verified = True
                            break
                    elif kind == 'close':
                        break
                service.complete_login(uid, iid, stamp, verified)
                await send({'status': 'Авторизация подтверждена' if verified else 'Окно закрыто. Вход не подтверждён.'})
            await ws.close()
        except WebSocketDisconnect:
            pass
        except Exception:
            try:
                await send({'error': 'Доступ закрыт или браузер недоступен. Откройте окно заново.'})
                await ws.close(code=1008)
            except Exception:
                pass

    return app


app = create_app()
